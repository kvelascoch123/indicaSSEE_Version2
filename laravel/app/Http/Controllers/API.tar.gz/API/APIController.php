<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\APIServiceRepository;

class APIController extends Controller
{

    public function prueba_api()
    {
      echo "Prueba api";

    }

    public function getUser($nombre, $contrasena)
    {
      $api = new  APIServiceRepository();
      $usuario = $api->getUser($nombre, $contrasena);
     // print_r($usuario);
      return response()->json([
        'data'=> [
        'email' => $usuario[0]->email,
        'name' => $usuario[0]->name
        ]
        
    ]);
    } 
}
