<?php

namespace App\Repositories;

use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\DB;

use Carbon\Carbon; 


class DataServiceRepository {

 
	

    public function __construct() {
       
    }
    
    // Indicador Mes Año
    public function indicatorMonthYear($indicador, $mes, $anio) {
        $indicadores = DB::select('SELECT * FROM `al_indicators_years` WHERE name ="' . $indicador . '" and  month = "' . $mes . '" and year =  ' . $anio . '');
        return $indicadores;
    }

    // Indicador Año

    public function indicatorYear($indicador, $anio){
        $indicadores = DB::select('SELECT * FROM `al_indicators_years` WHERE name ="' . $indicador . '" and year =  ' . $anio . '');
        return $indicadores;
    }

    // Calculos VALOR 

}